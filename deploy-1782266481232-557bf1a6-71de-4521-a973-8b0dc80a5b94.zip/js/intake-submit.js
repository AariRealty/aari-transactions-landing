/* ============================================================================
   Aari Transactions — Intake submit + draft glue (Part 1 final)
   ============================================================================
   Owns the agent's "Submit File →" click. Supabase is the source of truth.
   Flow:

     1. Generate file_id (UUID) up front so it can flow through Supabase,
        Storage, Stripe metadata, and the thank-you redirect.
     2. Upload the SignaturePad PNG to Storage at
        signatures/{agent_id}/{file_id}_v{version}.png   (RLS-protected)
     3. Insert into public.agreement_signatures (immutable evidence row),
        then fire-and-forget invoke aari-sa-pdf-email so the
        personalized signed PDF appears in the agent's dashboard within ~30s.
     4. Insert into public.files with M2 columns:
          status='intake_received'
          billed_via, payment_timing
          signed_agreement_version, signature_image_url
          is_aari_engaged=true (intake came through Aari)
     5. Clear any draft, then redirect:
          upfront → Stripe Payment Link with file_id, agent_id,
                    service_type, service_price metadata in the URL
          at-closing → /thank-you?status=submitted&svc=&file_id=

   Errors:
     - Anonymous (no Supabase session): show inline alert telling the agent
       to register or sign in. Do NOT post to Firebase, do NOT redirect.
     - Supabase write fails: show error, write audit_log, do NOT redirect.
     - Storage upload fails: still write the files row (signature_image_url
       null, drawn_signature_data carried in raw_form_data). Best effort.

   Also injects the "Save & exit" button and listens for the resume-intake
   event from draft-detection.js.
   ============================================================================ */

(function (global) {
  'use strict';

  const SERVICE_AGREEMENT_VERSION = 'v4.7';
  const SERVICE_TYPE_TO_PAYMENT = {
    tc_one_side:         { timing: 'at_closing', billed_via: 'pay_at_closing_da' },
    tc_both_sides:       { timing: 'at_closing', billed_via: 'pay_at_closing_da' },
    lc:                  { timing: 'upfront',    billed_via: 'stripe_upfront' },
    op_basic:            { timing: 'upfront',    billed_via: 'stripe_upfront' },
    op_complete:         { timing: 'upfront',    billed_via: 'stripe_upfront' },
    listing_docs:        { timing: 'upfront',    billed_via: 'stripe_upfront' },
    mls_setup:           { timing: 'upfront',    billed_via: 'stripe_upfront' },
    file_org:            { timing: 'upfront',    billed_via: 'stripe_upfront' },
  };

  // ============== service_type → file_type ==============
  // Drives /files.html kanban routing + verification config selection.
  // No new intake field needed — the service the agent picks already tells
  // us the workflow. Add-ons (op_basic, op_complete, file_org) default to
  // sale since that's the most common context; the TC can re-route on
  // /files.html if it's actually attached to a listing or lease.
  const SERVICE_TYPE_TO_FILE_TYPE = {
    tc_one_side:   'sale',
    tc_both_sides: 'sale',
    lc:            'listing',
    listing_docs:  'listing',
    mls_setup:     'listing',
    op_basic:      'sale',
    op_complete:   'sale',
    file_org:      'sale',
  };

  // Stripe Payment Link URLs by service id. Mirrors the SERVICES catalog
  // inside the intake IIFE in index.html (which we no longer let run for
  // upfront submissions, since we own the redirect ourselves).
  const SERVICE_STRIPE_URLS = {
    lc:                'https://buy.stripe.com/dRm3cn77V6in5Cj9QScAo0h',
    op_basic:          'https://buy.stripe.com/3cI5kv63R227ggXbZ0cAo07',
    op_complete:       'https://buy.stripe.com/6oUfZ99g3gX18Ov4wycAo05',
    listing_docs:      'https://buy.stripe.com/6oU7sD8bZbCH3ubfbccAo08',
    mls_setup:         'https://buy.stripe.com/fZu5kvgIvbCH7Kr7IKcAo09',
    file_org:          'https://buy.stripe.com/6oU00b2RF6infcT8MOcAo0f',
  };

  function uuid() {
    if (crypto && typeof crypto.randomUUID === 'function') return crypto.randomUUID();
    // RFC4122 v4 fallback
    const b = crypto.getRandomValues(new Uint8Array(16));
    b[6] = (b[6] & 0x0f) | 0x40;
    b[8] = (b[8] & 0x3f) | 0x80;
    const h = Array.from(b).map(x => x.toString(16).padStart(2, '0'));
    return `${h.slice(0,4).join('')}-${h.slice(4,6).join('')}-${h.slice(6,8).join('')}-${h.slice(8,10).join('')}-${h.slice(10,16).join('')}`;
  }

  function num(v) {
    if (v == null || v === '') return null;
    const cleaned = String(v).replace(/[^0-9.]/g, '');
    const n = parseFloat(cleaned);
    return Number.isFinite(n) ? Math.round(n * 100) : null;
  }

  function dataUrlToBlob(dataUrl) {
    if (!dataUrl) return null;
    const [meta, b64] = dataUrl.split(',');
    if (!meta || !b64) return null;
    const mime = (meta.match(/data:([^;]+)/) || [, 'image/png'])[1];
    const bin = atob(b64);
    const arr = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
    return new Blob([arr], { type: mime });
  }

  function serializeFormData(fd) {
    const obj = {};
    for (const [k, v] of fd.entries()) {
      if (v instanceof File) {
        obj[k] = v.name ? { filename: v.name, size: v.size, type: v.type } : null;
        continue;
      }
      if (k in obj) obj[k] = [].concat(obj[k], v);
      else obj[k] = v;
    }
    return obj;
  }

  function whenReady(cb) {
    const tryNow = () => {
      const form = document.getElementById('intake-form');
      const foot = document.querySelector('#intake-modal .modal-foot');
      const submitBtn = document.getElementById('intakeSubmit');
      if (form && foot && submitBtn) cb({ form, foot, submitBtn });
      else setTimeout(tryNow, 60);
    };
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', tryNow);
    else tryNow();
  }

  // ===== ERROR ALERT =====
  function showAlert(message, kind) {
    let slot = document.getElementById('aari-intake-alert');
    if (!slot) {
      slot = document.createElement('div');
      slot.id = 'aari-intake-alert';
      slot.style.cssText = 'position:fixed;left:50%;bottom:24px;transform:translateX(-50%);z-index:1300;max-width:520px;width:calc(100% - 48px)';
      document.body.appendChild(slot);
    }
    slot.innerHTML = '';
    const a = document.createElement('div');
    a.className = 'aari-alert ' + (kind || 'error');
    a.style.cssText = 'box-shadow:0 12px 32px rgba(0,0,0,0.18)';
    a.textContent = message;
    slot.appendChild(a);
    setTimeout(() => slot.contains(a) && a.remove(), 8000);
  }

  // ===== STRIPE PAYMENT LINK =====
  // The Stripe URLs live on the SERVICES catalog inside the intake IIFE
  // (as `svc.stripe`). The hidden form field `service_id` carries the id by
  // the time the user reaches Step 5, so we read both here.
  function buildStripeRedirectUrl(stripeUrl, params) {
    if (!stripeUrl) return null;
    // Stripe Payment Links accept URL params:
    //   ?prefilled_email=...
    //   ?prefilled_metadata[file_id]=...&prefilled_metadata[agent_id]=...
    const u = new URL(stripeUrl);
    if (params.email) u.searchParams.set('prefilled_email', params.email);
    if (params.file_id) u.searchParams.set('prefilled_metadata[file_id]', params.file_id);
    if (params.agent_id) u.searchParams.set('prefilled_metadata[agent_id]', params.agent_id);
    if (params.service_type) u.searchParams.set('prefilled_metadata[service_type]', params.service_type);
    if (params.service_price_cents != null) u.searchParams.set('prefilled_metadata[service_price_cents]', String(params.service_price_cents));
    return u.toString();
  }

  function buildThankYouUrl(status, serviceType, fileId) {
    const u = new URL('/thank-you.html', window.location.origin);
    u.searchParams.set('status', status);
    if (serviceType) u.searchParams.set('svc', serviceType);
    if (fileId) u.searchParams.set('file_id', fileId);
    return u.toString();
  }

  // ===== MAIN: hijack the Submit click =====
  function installSubmitHijack(form, submitBtn) {
    // Capture-phase listener on document fires BEFORE the click reaches the
    // submit button (capture travels window → document → ... → target).
    // stopImmediatePropagation here cancels propagation entirely, so the
    // existing inline bubble-phase handler on the button never runs.
    // (A capture listener on the button itself would NOT do this — same-target
    // listeners fire in registration order regardless of phase.)
    console.log('[intake-submit] hijack installed · waiting for submit clicks');
    document.addEventListener('click', (e) => {
      const t = e.target;
      const inSubmit = t === submitBtn || (submitBtn.contains && submitBtn.contains(t));
      if (!inSubmit) return;
      // ── Yield to Path A / Path B ────────────────────────────────────────
      // Path A (returning-agent file wizard) and Path B (in-modal signup) each
      // own their own submit handler, wired in index.html (the bubble-phase
      // listener on #intakeSubmit at ~line 9565 routes to AariPathA.submit()).
      // This legacy SERVICES hijack must NOT intercept their clicks — if it
      // does, stopImmediatePropagation() below kills the bubble handler and the
      // file is never uploaded (submit appears to "do nothing"). Return WITHOUT
      // preventDefault/stopImmediatePropagation so the click bubbles normally.
      // Yield whenever Path A / Path B is active OR simply visible on screen. The
      // visibility check is the belt-and-suspenders: inside the portal iframe
      // isActive() can momentarily read false, and without this the hijack would
      // swallow the click before Path A's own submit handler (index.html) runs —
      // which is exactly the "Send My File does nothing" failure.
      var _vis = function(id){ var el = document.getElementById(id); return !!(el && !el.hidden && el.offsetParent !== null); };
      var paOn = (global.AariPathA && typeof global.AariPathA.isActive === 'function' && global.AariPathA.isActive()) || _vis('aariPathA');
      var pbOn = (global.AariPathB && typeof global.AariPathB.isActive === 'function' && global.AariPathB.isActive()) || _vis('aariPathB');
      if (paOn || pbOn) {
        console.log('[intake-submit] Path A/B active/visible · yielding to its own submit handler');
        return;
      }
      // ── DIAGNOSTIC LOGGING · removed once submit is verified reliable ──
      // If a future click on Submit "does nothing," the console + on-screen
      // alert tell us EXACTLY which gate it hit. Each return path below now
      // surfaces a visible error so Marlenyi doesn't need DevTools to debug.
      console.log('[intake-submit] click intercepted on submit button');
      const modal = document.getElementById('intake-modal');
      if (!modal) {
        console.error('[intake-submit] modal element missing');
        showAlert('Submit failed · intake modal element missing. Refresh and retry.');
        return;
      }
      if (modal.hasAttribute('hidden')) {
        console.error('[intake-submit] modal is hidden · click ignored');
        showAlert('Submit failed · modal is hidden. Refresh and retry.');
        return;
      }
      if (submitBtn.disabled) {
        console.warn('[intake-submit] submit already in-flight · click ignored');
        return;
      }
      e.preventDefault();
      e.stopImmediatePropagation();
      console.log('[intake-submit] handleSubmit starting');
      handleSubmit(form, submitBtn).catch(err => {
        console.error('[intake-submit] unexpected:', err);
        // Surface BOTH the message AND the underlying stack tail so a
        // production-only failure is debuggable from the visible alert alone.
        const tail = (err && err.stack && err.stack.split('\n').slice(0, 3).join(' · ')) || '';
        showAlert(
          (err && err.message ? err.message : 'Unexpected error.') +
          (tail ? ' [' + tail + ']' : '')
        );
        submitBtn.disabled = false;
        submitBtn.textContent = 'Submit File →';
      });
    }, true);
  }

  async function handleSubmit(form, submitBtn) {
    submitBtn.disabled = true;
    submitBtn.textContent = 'Submitting…';
    console.log('[intake-submit] handleSubmit ENTRY · form:', form && form.id, 'submitBtn:', submitBtn && submitBtn.id);

    const fd = new FormData(form);

    // Mirror the existing handler's last-step bookkeeping that we just
    // intercepted: it sets payment_status + intake-next based on service.
    // We re-do the relevant bits ourselves.
    const serviceId = fd.get('service_id') || document.getElementById('intakeServiceId').value;
    const serviceName = fd.get('service_name') || document.getElementById('intakeServiceName').value;
    const servicePriceStr = fd.get('service_price') || document.getElementById('intakeServicePrice').value;
    const service_price_cents = servicePriceStr ? Math.round(parseFloat(servicePriceStr) * 100) : null;
    console.log('[intake-submit] serviceId:', serviceId, '· serviceName:', serviceName, '· price_cents:', service_price_cents);

    if (!serviceId) {
      submitBtn.disabled = false;
      submitBtn.textContent = 'Submit File →';
      showAlert('No service selected. Go back to Step 1 and pick a service.');
      return;
    }

    if (!global.AariAuth) {
      submitBtn.disabled = false;
      submitBtn.textContent = 'Submit File →';
      showAlert('The auth module did not load. Refresh and try again.');
      return;
    }

    console.log('[intake-submit] resolving session…');
    const session = await global.AariAuth.getCurrentSession();
    if (!session) {
      submitBtn.disabled = false;
      submitBtn.textContent = 'Submit File →';
      showAlert('Please sign in or register before submitting a file.');
      if (global.AariLogin) global.AariLogin.open();
      return;
    }
    console.log('[intake-submit] session resolved · agent:', session.user && session.user.id);
    const agentId = session.user.id;

    const fileId = uuid();
    const client = await global.AariAuth.ensureClient();

    // ===== 1. Upload signature PNG to Storage (best effort) =====
    let signatureUrl = null;
    try {
      const drawn = fd.get('service_agreement_drawn');
      const blob = dataUrlToBlob(drawn);
      if (blob) {
        const path = `${agentId}/${fileId}_${SERVICE_AGREEMENT_VERSION}.png`;
        const up = await client.storage.from('signatures').upload(path, blob, {
          contentType: blob.type || 'image/png',
          upsert: false,
        });
        if (!up.error) {
          // Storage path is enough — the dashboard uses createSignedUrl on demand.
          signatureUrl = path;
        } else {
          console.warn('[intake-submit] signature upload failed:', up.error);
        }
      }
    } catch (sigErr) {
      console.warn('[intake-submit] signature upload threw:', sigErr);
    }

    // ===== 2. Insert files row FIRST (so agreement_signatures.file_id FK is satisfied) =====
    // Order matters: agreement_signatures.file_id references public.files(id). If we
    // insert the signature row first, the FK fails with sqlstate 23503.
    const billing = SERVICE_TYPE_TO_PAYMENT[serviceId] || { timing: null, billed_via: null };
    const fileRow = {
      id: fileId,
      agent_id: agentId,
      service_type: serviceId,
      file_type: SERVICE_TYPE_TO_FILE_TYPE[serviceId] || 'sale',
      service_price_cents,
      client_type: fd.get('client_type'),
      client_name: fd.get('client_name') || fd.get('seller_name') || fd.get('buyer_name'),
      client_email: fd.get('client_email') || fd.get('seller_email') || fd.get('buyer_email'),
      client_phone: fd.get('client_phone') || fd.get('seller_phone') || fd.get('buyer_phone'),
      property_address: fd.get('address'),
      effective_date: fd.get('effective_date') || null,
      closing_date: fd.get('closing_date') || fd.get('closing_date_target') || null,
      purchase_price_cents: num(fd.get('purchase_price') || fd.get('offer_price') || fd.get('listing_price')),
      earnest_money_cents: num(fd.get('earnest_money') || fd.get('earnest_money_offer')),
      lender_contact: fd.get('lender_contact') || null,
      title_contact: fd.get('title_contact') || null,
      assigned_tc_id: null,
      service_agreement_signed: true,
      // Display-only convenience timestamp on the files row. The authoritative
      // ESIGN signing timestamp + IP live on agreement_signatures (server-side),
      // captured by the record-signed-agreement edge function below.
      service_agreement_signed_at: new Date().toISOString(),
      service_agreement_typed_name: fd.get('service_agreement_typed_name') || null,
      service_agreement_signature_data: signatureUrl ? null : (fd.get('service_agreement_drawn') || null),
      signed_agreement_version: SERVICE_AGREEMENT_VERSION,
      signature_image_url: signatureUrl,
      is_aari_engaged: true,
      payment_timing: billing.timing,
      billed_via: billing.billed_via,
      payment_status: billing.timing === 'upfront' ? 'pending' : 'at_closing',
      status: 'intake_received',
      raw_form_data: serializeFormData(fd),
    };

    const { data: inserted, error: insertErr } = await client
      .from('files')
      .insert(fileRow)
      .select()
      .single();

    if (insertErr) {
      // Profile-level SA gate (DB trigger) · send them to sign, do not retry.
      if (/SA_NOT_SIGNED/.test(insertErr.message || '')) {
        alert('You need to sign the Service Agreement before submitting a file.');
        window.location.href = '/index.html#onboarding';
        return { ok: false, error: 'sa_not_signed' };
      }
      // Hard fail: do NOT redirect.
      try {
        await client.from('audit_log').insert({
          actor_id: agentId,
          actor_type: 'agent',
          action: 'intake_submit_failed',
          target_table: 'files',
          target_id: fileId,
          details: { error: { code: insertErr.code, message: insertErr.message } },
        });
      } catch (e) {}
      console.error('[intake-submit] files insert failed:', insertErr);
      submitBtn.disabled = false;
      submitBtn.textContent = 'Submit File →';
      showAlert('We couldn\'t save your file. ' + (insertErr.message || 'Please try again or contact hello@aaritransactions.com.'));
      return;
    }

    // ===== 2.5 · Persist agent's confidential remarks template (if opted in) =====
    // The listing intake's confidential remarks widget surfaces a checkbox
    // "Save this as my default for future listings." When checked, the widget
    // attempts an immediate save, but we also re-fire here at submit time as
    // a safety net (handles the case where the agent typed AFTER ticking the
    // box, or the immediate save failed). Idempotent · no harm if duplicate.
    try {
      const saveFlag = fd.get('confidential_remarks_save_to_profile');
      const remarksSource = fd.get('confidential_remarks_source');
      const remarksText = fd.get('confidential_remarks');
      if (saveFlag === '1' && remarksSource === 'agent_custom' && typeof remarksText === 'string' && remarksText.trim().length > 0) {
        await client
          .from('agents')
          .update({ default_confidential_remarks: remarksText.trim() })
          .eq('id', agentId);
      }
    } catch (remarksSaveErr) {
      // Non-fatal · the file is already saved, the agent's template just didn't update.
      console.warn('[intake-submit] confidential remarks template save failed:', remarksSaveErr);
    }

    // ===== 3. Record signature via edge function (Section 6.2 audit fix) =====
    // Routes through the record-signed-agreement edge function so the IP can be
    // captured from request headers and the timestamp is set server-side
    // (not by the browser clock). The edge function then fire-and-forgets the
    // aari-sa-pdf-email invocation. Old client-side insert (which
    // hardcoded ip_address: null and used new Date().toISOString()) is gone.
    try {
      const { data: rec, error: recErr } = await client.functions.invoke('record-signed-agreement', {
        body: {
          agent_id: agentId,
          file_id: fileId,
          agreement_type: 'service_agreement',
          agreement_version: SERVICE_AGREEMENT_VERSION,
          typed_full_name: fd.get('service_agreement_typed_name') || '',
          drawn_signature_data: signatureUrl ? null : (fd.get('service_agreement_drawn') || null),
          signature_image_url: signatureUrl,
          user_agent: navigator.userAgent,
        },
      });
      if (recErr) {
        console.warn('[intake-submit] record-signed-agreement failed:', recErr);
      } else if (rec && rec.signature_id) {
        // PDF gen chain happens inside the edge function — nothing more to do here.
      }
    } catch (sigRowErr) {
      console.warn('[intake-submit] record-signed-agreement threw:', sigRowErr);
      // Non-fatal — the file row already captured the signature path; PDF can be
      // re-generated manually via the replay curl in README.
    }

    // ===== 4. Clear draft, then redirect =====
    if (global.AariDraft) {
      try { await global.AariDraft.clear(); } catch (e) {}
    }

    // Resolve the Stripe Payment Link URL ourselves. We can't rely on the
    // existing intake IIFE's `intake-next` hidden field — its bubble-phase
    // click handler is cancelled by stopImmediatePropagation above and never
    // gets a chance to set it. SERVICE_STRIPE_URLS is the source of truth.
    const stripeUrl = SERVICE_STRIPE_URLS[serviceId] || null;

    const agentEmail = (await safeGetAgentEmail()) || (fd.get('agent_email') || '');

    // Fire a custom event the page's modal-only script forwards to the parent
    // window (the portal's iframe overlay) so the portal can close the popup
    // and refresh the agent's file list. Browsers ignore it on standalone pages.
    // Detect whether we're running inside the portal's iframe overlay.
    const inFrame = (function(){ try { return window.parent && window.parent !== window; } catch(_) { return false; } })();

    // May 2026 · Phase 2 of lifecycle flow · inline success instead of redirect
    // At-closing services (TC): render success card in modal, agent stays put.
    // Upfront services (LC, OP, MLS Setup, etc.): briefly show success card so
    // the agent sees acknowledgement, then redirect to Stripe checkout.
    const successOpts = {
      fileId,
      serviceId,
      serviceName,
      agentId,
      propertyAddress: fd.get('address') || fd.get('property_address') || null,
      assignedTcName: fd.get('intakePreferredTc') || document.getElementById('intakePreferredTc')?.value || null,
    };

    if (billing.timing === 'upfront') {
      const url = buildStripeRedirectUrl(stripeUrl, {
        email: agentEmail,
        file_id: fileId,
        agent_id: agentId,
        service_type: serviceId,
        service_price_cents,
      }) || buildThankYouUrl('unpaid', serviceId, fileId);
      // Show success card for 1.5s then redirect to Stripe. When we're inside the
      // portal overlay we must navigate the TOP window — Stripe refuses to load in
      // an iframe, and we do NOT auto-close the overlay here (that would kill the
      // redirect). On a standalone page window.top === window, so behavior is
      // unchanged.
      renderInlineSuccess({ ...successOpts, primaryCtaLabel: 'Continue to payment →', primaryCtaUrl: url });
      setTimeout(() => { (inFrame ? window.top : window).location.href = url; }, 1500);
    } else {
      // At-closing (TC): safe to tell the portal overlay to close + refresh the
      // file list. Browsers ignore this event on standalone pages.
      try {
        window.dispatchEvent(new CustomEvent('aari:intake-submitted', {
          detail: { fileId: fileId, serviceId: serviceId, agentId: agentId }
        }));
      } catch (_) {}
      renderInlineSuccess({ ...successOpts, primaryCtaLabel: 'Open in portal →', primaryCtaUrl: '/portal.html' });
    }
  }

  // ====================================================================
  // Inline success renderer · May 2026
  // Swaps the modal's form + footer for a confirmation card with the TC
  // assignment, file ID, and a single primary CTA. Used by both at-closing
  // (stays in modal) and upfront (briefly shown before Stripe redirect).
  // ====================================================================
  function renderInlineSuccess(opts) {
    const box = document.getElementById('intake-modal-box');
    const view = document.getElementById('intakeSuccessView');
    if (!box || !view) {
      // Fallback if the success markup isn't present · old redirect path
      if (opts.primaryCtaUrl) window.location.href = opts.primaryCtaUrl;
      return;
    }
    box.setAttribute('data-success-state', 'true');
    view.hidden = false;

    // File ID · first 8 chars upper-case for readability
    const shortId = String(opts.fileId || '').slice(0, 8).toUpperCase();
    setText('intakeSuccessFileId', shortId ? '#' + shortId : '—');
    setText('intakeSuccessServiceName', opts.serviceName || '—');
    if (opts.propertyAddress) {
      setText('intakeSuccessProperty', opts.propertyAddress);
    } else {
      const row = document.getElementById('intakeSuccessPropertyRow');
      if (row) row.style.display = 'none';
    }

    // TC card · branch on whether a specific TC was picked or fast-path
    const tcName = opts.assignedTcName;
    const autoCard = document.getElementById('intakeSuccessAutoCard');
    const tcCard = document.getElementById('intakeSuccessTcCard');
    if (tcName && tcName !== 'auto-assign' && tcName !== 'auto') {
      // Find TC photo from window.tcsData if available
      let photo = '';
      try {
        const tc = (window.tcsData || []).find(t => t.displayName === tcName);
        if (tc) photo = tc.photoUrl;
      } catch (_) {}
      const img = document.getElementById('intakeSuccessTcPhoto');
      if (img && photo) { img.src = photo; img.alt = tcName; }
      setText('intakeSuccessTcName', tcName);
      tcCard.hidden = false;
      autoCard.hidden = true;
    } else {
      tcCard.hidden = true;
      autoCard.hidden = false;
    }

    // Primary CTA
    const primary = document.getElementById('intakeSuccessPrimary');
    if (primary) {
      primary.textContent = opts.primaryCtaLabel || 'Open in portal →';
      primary.onclick = () => {
        if (opts.primaryCtaUrl) window.location.href = opts.primaryCtaUrl;
      };
    }
  }

  function setText(id, val) {
    const el = document.getElementById(id);
    if (el) el.textContent = val == null ? '—' : String(val);
  }

  async function safeGetAgentEmail() {
    try {
      const profile = await global.AariAuth.getAgentProfile();
      return profile && profile.email;
    } catch (e) { return null; }
  }

  // ===== SAVE & EXIT =====
  function installSaveAndExit(foot) {
    if (document.getElementById('intakeSaveExit')) return;
    const btn = document.createElement('button');
    btn.id = 'intakeSaveExit';
    btn.type = 'button';
    btn.textContent = 'Save & exit';
    btn.className = 'btn-step';
    btn.style.cssText = 'background:transparent;border:1px solid currentColor;opacity:0.85;margin-right:auto';
    foot.insertBefore(btn, foot.firstChild);

    btn.addEventListener('click', async () => {
      const form = document.getElementById('intake-form');
      const fd = new FormData(form);
      const stepLabel = (document.getElementById('intakeStepLabel') || {}).textContent || '';
      const stepMatch = stepLabel.match(/(\d+)/);
      const currentStep = stepMatch ? parseInt(stepMatch[1], 10) : 1;
      const serviceId = (document.getElementById('intakeServiceId') || {}).value || null;
      const propertyAddress = fd.get('address') || null;

      if (global.AariDraft) {
        try {
          await global.AariDraft.save({
            service_type: serviceId,
            current_step: currentStep,
            form_data: serializeFormData(fd),
            property_address: propertyAddress,
          });
          showAlert('Draft saved. We\'ll restore it next visit.', 'success');
        } catch (e) {
          showAlert('Saved locally — will sync next time you sign in.', 'success');
        }
      }
      const closeBtn = document.getElementById('intake-close');
      if (closeBtn) closeBtn.click();
    });
  }

  // ===== RESUME =====
  function installResumeHandler() {
    window.addEventListener('aari:resume-intake', (e) => {
      const draft = e.detail && e.detail.draft;
      if (!draft) return;
      const trigger = document.querySelector('[data-intake-trigger]');
      if (trigger) trigger.click();
      setTimeout(() => applyDraftToForm(draft), 60);
    });
  }

  function applyDraftToForm(draft) {
    if (draft.service_type) {
      const card = document.querySelector('.service-card[data-service-id="' + draft.service_type + '"]');
      if (card) card.click();
    }
    const data = draft.form_data || {};
    const form = document.getElementById('intake-form');
    if (!form) return;
    Object.keys(data).forEach(k => {
      const v = data[k];
      const el = form.querySelector('[name="' + cssEscape(k) + '"]');
      if (!el || el.type === 'file') return;
      if (el.type === 'radio') {
        const r = form.querySelector('[name="' + cssEscape(k) + '"][value="' + cssEscape(String(v)) + '"]');
        if (r) r.checked = true;
        return;
      }
      if (el.type === 'checkbox') { el.checked = !!v; return; }
      if (typeof v === 'object') return;
      el.value = v == null ? '' : String(v);
    });
    walkToStep(Math.max(1, Math.min(5, parseInt(draft.current_step || 1, 10))));
  }

  function walkToStep(target) {
    const label = document.getElementById('intakeStepLabel');
    if (!label) return;
    const cur = (label.textContent.match(/(\d+)/) || [])[1];
    const current = cur ? parseInt(cur, 10) : 1;
    if (current >= target) return;
    const nextBtn = document.getElementById('intakeNext');
    if (!nextBtn || nextBtn.hidden) return;
    nextBtn.click();
    setTimeout(() => walkToStep(target), 120);
  }

  function cssEscape(s) {
    return String(s).replace(/(["\\])/g, '\\$1');
  }

  // ===== Bootstrap =====
  whenReady(({ form, foot, submitBtn }) => {
    installSubmitHijack(form, submitBtn);
    // Save & exit removed (May 2026 audit · "X discards" pattern).
    // The X button in the modal header now handles all exits via a confirm
    // dialog. Cross-device draft resume is dormant — installResumeHandler
    // stays bootable for any legacy drafts already in Supabase.
    installResumeHandler();
  });
})(window);
